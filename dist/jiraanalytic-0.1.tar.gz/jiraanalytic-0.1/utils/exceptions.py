class JiraAPIException(Exception):
    """Исключение для ошибок JIRA API."""
    pass